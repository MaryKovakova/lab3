from setuptools import setup, find_packages

setup(
    name='lab3',
    version='1.0',
    scripts=['lab3_graphs.py'],
    description="Программное средство для визуализации аналитики задач проекта Apache Kafka",
    packages=['lab3'],
    url="https://github.com/MaryKovakova/lab3",
    author="Alexa Lea",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        "certifi==2023.11.17",
        "charset-normalizer==3.3.2",
        "contourpy==1.2.0",
        "cycler==0.12.1",
        "fonttools==4.44.3",
        "idna==3.4",
        "kiwisolver==1.4.5",
        "matplotlib==3.8.2",
        "numpy==1.26.2",
        "packaging==23.2",
        "pandas==2.1.3",
        "Pillow==10.1.0",
        "pyparsing==3.1.1",
        "python-dateutil==2.8.2",
        "pytz==2023.3.post1",
        "requests==2.31.0",
        "setuptools==68.2.2",
        "six==1.16.0",
        "tzdata==2023.3",
        "urllib3==2.1.0"
    ],
    python_requires=">=3.10",

)
